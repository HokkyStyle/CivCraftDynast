package com.dynast.civcraft.interactive;

public class InteractiveCapitulateCommand {

}
