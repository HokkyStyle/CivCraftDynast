package com.dynast.civcraft.populators;

import com.dynast.civcraft.config.ConfigRuin;
import com.dynast.civcraft.util.ChunkCoord;

public class RuinPick {
    public ChunkCoord chunkCoord;
    public ConfigRuin jungleRuin = null;
    public ConfigRuin desertRuin = null;
    public ConfigRuin landRuin = null;
}
