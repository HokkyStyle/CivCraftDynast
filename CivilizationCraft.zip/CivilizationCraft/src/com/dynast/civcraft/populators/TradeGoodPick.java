
package com.dynast.civcraft.populators;

import com.dynast.civcraft.config.ConfigTradeGood;
import com.dynast.civcraft.util.ChunkCoord;

public class TradeGoodPick {
	public ChunkCoord chunkCoord;
	public ConfigTradeGood landPick;
	public ConfigTradeGood waterPick;
	
}
