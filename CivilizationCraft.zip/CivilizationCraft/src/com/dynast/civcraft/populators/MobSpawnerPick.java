package com.dynast.civcraft.populators;

import com.dynast.civcraft.config.ConfigMobSpawner;
import com.dynast.civcraft.util.ChunkCoord;

public class MobSpawnerPick {
    public ChunkCoord chunkCoord;
    public ConfigMobSpawner landPick;
    public ConfigMobSpawner waterPick;
}
