package com.dynast.civcraft.structure;

public class BuildableLayer {
	public BuildableLayer(int cur, int max) {
		this.current = cur;
		this.max = max;
	}
	
	public int current;
	public int max;
}
