
package com.dynast.civcraft.object;

public class Government {
//is this needed?
}
