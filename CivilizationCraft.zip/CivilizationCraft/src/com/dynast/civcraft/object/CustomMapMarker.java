
package com.dynast.civcraft.object;

public class CustomMapMarker {
	public String name;
	public String description;
	public String icon;
}
