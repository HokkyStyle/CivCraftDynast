
package com.dynast.civcraft.object;

import java.util.Date;

public class Dates {

	public static Date lastSpawnRegenDate = null;
	
	
}
