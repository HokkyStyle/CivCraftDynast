package com.dynast.civcraft.questions;

public class QuestionBaseTask {

}
