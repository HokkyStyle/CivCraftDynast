package com.dynast.civcraft.components;

public abstract class AttributeBaseRate extends Component {
	public abstract double getGenerated();
}
