
package com.dynast.civcraft.components;

public class SifterItem {
	public int source_type;
	public short source_data;
	public double rate;
	
	public int result_type;
	public int result_data;
	public int amount;
}
