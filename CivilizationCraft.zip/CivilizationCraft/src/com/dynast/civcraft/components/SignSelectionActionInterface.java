
package com.dynast.civcraft.components;

import org.bukkit.entity.Player;

public interface SignSelectionActionInterface {
	public void process(Player player);
}
