package com.dynast.civcraft.components;

public class Attribute {
	public enum TypeKeys {
		COINS,
		HAPPINESS,
		HAMMERS,
		GROWTH,
		BEAKERS
	}
}
