
package com.dynast.civcraft.components;

public class ConsumeLevelEquivExchange {

	public int baseType;
	public int altType;
	public int basePerAlt;
	
	
}
