package com.dynast.civcraft.components;

public abstract class AttributeBase extends Component {	
	public abstract double getGenerated();
}
