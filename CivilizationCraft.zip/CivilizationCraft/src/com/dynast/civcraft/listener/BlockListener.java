package com.dynast.civcraft.listener;

import java.util.HashSet;
import java.util.List;
import java.util.Random;

import com.dynast.civcraft.config.ConfigJobLevels;
import com.dynast.civcraft.config.ConfigTechPotion;
import com.dynast.civcraft.util.*;
import me.desht.dhutils.block.BlockType;
import net.citizensnpcs.api.npc.NPC;
import net.minecraft.server.v1_11_R1.*;

import net.minecraft.server.v1_11_R1.Entity;
import org.bukkit.*;
import org.bukkit.Chunk;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.v1_11_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_11_R1.entity.CraftLivingEntity;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.event.world.PortalCreateEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SpawnEggMeta;
import org.bukkit.material.Crops;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import com.dynast.civcraft.cache.ArrowFiredCache;
import com.dynast.civcraft.cache.CannonFiredCache;
import com.dynast.civcraft.cache.CivCache;
import com.dynast.civcraft.camp.Camp;
import com.dynast.civcraft.camp.CampBlock;
import com.dynast.civcraft.config.CivSettings;
import com.dynast.civcraft.exception.CivException;
import com.dynast.civcraft.main.CivData;
import com.dynast.civcraft.main.CivGlobal;
import com.dynast.civcraft.main.CivMessage;
import com.dynast.civcraft.object.ControlPoint;
import com.dynast.civcraft.object.ProtectedBlock;
import com.dynast.civcraft.object.Resident;
import com.dynast.civcraft.object.StructureBlock;
import com.dynast.civcraft.object.StructureChest;
import com.dynast.civcraft.object.StructureSign;
import com.dynast.civcraft.object.TownChunk;
import com.dynast.civcraft.permission.PlotPermissions;
import com.dynast.civcraft.road.Road;
import com.dynast.civcraft.road.RoadBlock;
import com.dynast.civcraft.structure.Buildable;
import com.dynast.civcraft.structure.BuildableLayer;
import com.dynast.civcraft.structure.CannonShip;
import com.dynast.civcraft.structure.CannonTower;
import com.dynast.civcraft.structure.Farm;
import com.dynast.civcraft.structure.Pasture;
import com.dynast.civcraft.structure.Wall;
import com.dynast.civcraft.structure.farm.FarmChunk;
import com.dynast.civcraft.structure.wonders.Battledome;
import com.dynast.civcraft.structure.wonders.GrandShipIngermanland;
import com.dynast.civcraft.threading.CivAsyncTask;
import com.dynast.civcraft.threading.TaskMaster;
import com.dynast.civcraft.threading.tasks.FireWorkTask;
import com.dynast.civcraft.threading.tasks.StructureBlockHitEvent;
import com.dynast.civcraft.war.War;
import com.dynast.civcraft.war.WarRegen;

public class BlockListener implements Listener {

	/* Experimental, reuse the same object because it is single threaded. */
	public static ChunkCoord coord = new ChunkCoord("", 0, 0);
	public static BlockCoord bcoord = new BlockCoord("", 0,0,0);

	@EventHandler(priority = EventPriority.NORMAL)
	public void onEntityTameEvent(EntityTameEvent event) {
		if (event.getEntity() instanceof Wolf) {
			Wolf wolf = (Wolf) event.getEntity();
			if (wolf.getName().contains("Direwolf")) {
				event.setCancelled(true);
			}
		}
	}
	
	@EventHandler(priority = EventPriority.NORMAL)
	public void onSlimeSplitEvent(SlimeSplitEvent event) {
		if (event.getEntity() instanceof Slime) {
			Slime slime = (Slime) event.getEntity();
			if (slime.getName().contains("Brutal") ||
					slime.getName().contains("Elite") ||
					slime.getName().contains("Greater") ||
					slime.getName().contains("Lesser")) {
				slime.setSize(0);
				event.setCancelled(true);
			}
		}
	}	

	@EventHandler(priority = EventPriority.NORMAL)
	public void onBlockIgniteEvent(BlockIgniteEvent event) {
	//	CivLog.debug("block ignite event");

		for (int x = -1; x <= 1; x++) {
			for (int y = -1; y <= 1; y++) {
				for (int z = -1; z <= 1; z++) {
					Block b = event.getBlock().getRelative(x, y, z);		
					bcoord.setFromLocation(b.getLocation());
					StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
					if (sb != null) {
						if (b.getType().isBurnable()) {
							event.setCancelled(true);
						}
						return;
					}

					RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
					if (rb != null) {
						event.setCancelled(true);
						return;
					}

					CampBlock cb = CivGlobal.getCampBlock(bcoord);
					if (cb != null) {
						event.setCancelled(true);
						return;
					}

					StructureSign structSign = CivGlobal.getStructureSign(bcoord);
					if (structSign != null) {
						event.setCancelled(true);
						return;
					}

					StructureChest structChest = CivGlobal.getStructureChest(bcoord);
					if (structChest != null) {
						event.setCancelled(true);
						return;
					}
				}
			}
	    }


		coord.setFromLocation(event.getBlock().getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);

		if (tc == null) {
			return;
		}

		if (tc.perms.isFire() == false) {
			CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("fireDisabledInChunk"));
			event.setCancelled(true);
		}		
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void onEntityBlockChange(EntityChangeBlockEvent event) {
		bcoord.setFromLocation(event.getBlock().getLocation());

		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
		if (sb != null) {
			event.setCancelled(true);
			return;
		}

		RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
		if (rb != null) {
			event.setCancelled(true);
			return;
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null) {
			event.setCancelled(true);
			return;
		}

		return;
	}

	@EventHandler(priority = EventPriority.LOW)
	public void onBlockBurnEvent(BlockBurnEvent event) {
		bcoord.setFromLocation(event.getBlock().getLocation());

		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
		if (sb != null) {
			event.setCancelled(true);
			return;
		}

		RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
		if (rb != null) {
			event.setCancelled(true);
			return;
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null) {
			event.setCancelled(true);
			return;
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void onProjectileHitEvent(ProjectileHitEvent event) {
		if (event.getEntity() instanceof Arrow) {
			ArrowFiredCache afc = CivCache.arrowsFired.get(event.getEntity().getUniqueId());
			if (afc != null) {
				afc.setHit(true);
			}
		}
		
		if (event.getEntity() instanceof Fireball) {
			CannonFiredCache cfc = CivCache.cannonBallsFired.get(event.getEntity().getUniqueId());
			if (cfc != null) {

				cfc.setHit(true);

				FireworkEffect fe = FireworkEffect.builder().withColor(Color.RED).withColor(Color.BLACK).with(Type.BURST).build();

				Random rand = new Random();
				int spread = 30;
				for (int i = 0; i < 3; i++) {
					int x = rand.nextInt(spread) - spread/2;
					int y = rand.nextInt(spread) - spread/2;
					int z = rand.nextInt(spread) - spread/2;


					Location loc = event.getEntity().getLocation();
					Location location = new Location(loc.getWorld(), loc.getX(),loc.getY(), loc.getZ());
					location.add(x, y, z);

					TaskMaster.syncTask(new FireWorkTask(fe, loc.getWorld(), loc, 1), rand.nextInt(30));
				}

			}
		}
	}

	@EventHandler(priority = EventPriority.LOWEST)
	public void onEntityDamageByEntityEvent(EntityDamageByEntityEvent event) {
		/* Protect the Protected Item Frames! */
		if (event.getEntity() instanceof ItemFrame) {
			ItemFrameStorage iFrameStorage = CivGlobal.getProtectedItemFrame(event.getEntity().getUniqueId());
			if (iFrameStorage != null) {
				event.setCancelled(true);
				return;
			}
		}

		if (event.getEntity() instanceof NPC) {
			return;
		}

		/*if (event.getDamager() instanceof LightningStrike) {
//			CivLog.debug("onEntityDamageByEntityEvent LightningStrike: "+event.getDamager().getUniqueId());
			try {
				event.setDamage(CivSettings.getInteger(CivSettings.warConfig, "tesla_tower.damage"));
			} catch (InvalidConfiguration e) {
				e.printStackTrace();
			}
		}*/

		/*if (event.getDamager() instanceof Arrow) {

		}*/

		if (event.getDamager() instanceof Fireball) {
			CannonFiredCache cfc = CivCache.cannonBallsFired.get(event.getDamager().getUniqueId());
			if (cfc != null) {

				cfc.setHit(true);
				cfc.destroy(event.getDamager());
				Buildable whoFired = cfc.getWhoFired();
				if (whoFired.getConfigId().equals("s_cannontower")) {
					event.setDamage((double)((CannonTower)whoFired).getDamage());
				} else if (whoFired.getConfigId().equals("s_cannonship")) {
					event.setDamage((double)((CannonShip)whoFired).getDamage());
				} else if (whoFired.getConfigId().equals("w_grand_ship_ingermanland")) {
					event.setDamage((double)((GrandShipIngermanland)whoFired).getCannonDamage());
				}
			}
		}
		
		if (event.getEntity() instanceof Player) {

			/* Only protect against players and entities that players can throw. */
			if (!CivSettings.playerEntityWeapons.contains(event.getDamager().getType())) {
				return;
			}

			Player defender = (Player)event.getEntity();
			Resident res = CivGlobal.getResident(defender);

			if (res == null) {
				event.setCancelled(true);
				return;
			}

		coord.setFromLocation(event.getEntity().getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);
		boolean allowPVP = false;
		String denyMessage = "";
		Arrow arrow = null;

		if (tc == null) {
			/* In the wilderness, anything goes. */
			allowPVP = true;
		} else {	
			Player attacker = null;
			if (event.getDamager() instanceof Player) {
				attacker = (Player)event.getDamager();
			} else if (event.getDamager() instanceof Projectile && ((Projectile)event.getDamager()).getShooter() instanceof LivingEntity) {
				LivingEntity shooter = (LivingEntity) ((Projectile)event.getDamager()).getShooter();
				if (shooter instanceof Player) {
					attacker = (Player) shooter;
				}
			}

			if (event.getDamager() instanceof  Arrow) {
				arrow = (Arrow) event.getDamager();
			}

			if (attacker == null) {
				/* Attacker wasnt a player or known projectile, allow it. */
				allowPVP = true;
			} else {
				switch(playersCanPVPHere(attacker, defender, tc)) {
				case ALLOWED:
					allowPVP = true;
					break;
				case NOT_AT_WAR:
					allowPVP = false;
					denyMessage = CivSettings.localize.localizedString("var_pvpError1",defender.getName());
					break;
				case NEUTRAL_IN_WARZONE:
					allowPVP = false;
					denyMessage = CivSettings.localize.localizedString("var_pvpError2",defender.getName());
					break;
				case NON_PVP_ZONE:
					allowPVP = false;
					denyMessage = CivSettings.localize.localizedString("var_pvpError3",defender.getName());
					break;
				}
			}

			if (!allowPVP) {
				if (arrow != null) {
					arrow.remove();
				}
				CivMessage.sendError(attacker, denyMessage);
				event.setCancelled(true);
			} else {

			}
		}
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onEntityCombustEvent(EntityCombustByEntityEvent event) {
		if (event.getEntity() instanceof LivingEntity && event.getCombuster() instanceof Arrow)  {
			Arrow arrow = (Arrow)event.getCombuster();
			if (arrow.getShooter() instanceof Player) {
				TownChunk tc = CivGlobal.getTownChunk(event.getEntity().getLocation());
				Player shooter = (Player) arrow.getShooter();
				Resident shooterr = CivGlobal.getResident(shooter);

				if (event.getEntity() instanceof Player) {
					Player entity = (Player) event.getEntity();
					if (tc != null) {
						if (!(playersCanPVPHere(shooter, entity, tc) == PVPDenyReason.ALLOWED)) {
							event.setCancelled(true);
							return;
						}
					}
				}

				if (shooterr.getCiv() != null && tc != null) {
					if (shooterr.getCiv() != tc.getTown().getCiv()) {
						event.setCancelled(true);
					}
				}
			}
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void OnCreateSpawnEvent(CreatureSpawnEvent event) {

		if (War.isWarTime()) {
			event.setCancelled(true);
			return;
		}

		if (event.getSpawnReason().equals(SpawnReason.BREEDING)) {
			ChunkCoord coord = new ChunkCoord(event.getEntity().getLocation());
			Pasture pasture = Pasture.pastureChunks.get(coord);

			if (pasture != null) {
				pasture.onBreed(event.getEntity());
			}
		}



		/*class SyncTask implements Runnable {
			LivingEntity entity;

			public SyncTask(LivingEntity entity) {
				this.entity = entity;
			}

			@Override
			public void run() {
				if (entity != null) {
					if (!HorseModifier.isCivCraftHorse(entity)) {
						CivLog.warning("Removing a normally spawned horse.");
						entity.remove();
					}
				}
			}
		}

		if (event.getEntityType() == EntityType.HORSE) {
			ChunkCoord coord = new ChunkCoord(event.getEntity().getLocation());
			Stable stable = Stable.stableChunks.get(coord);
			if (stable != null) {
				return;
			}
			
			if (event.getSpawnReason().equals(SpawnReason.DEFAULT)) {
				TaskMaster.syncTask(new SyncTask(event.getEntity()));
				return;
			}
			
			CivLog.warning("Canceling horse spawn reason:"+event.getSpawnReason().name());
			event.setCancelled(true);
		}*/

		coord.setFromLocation(event.getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);
		if (tc == null) {
			return;
		}

		if (!tc.perms.isMobs()) {
			if (event.getSpawnReason().equals(SpawnReason.CUSTOM)) {
				return;
			}

			ChunkCoord coord = new ChunkCoord(event.getEntity().getLocation());
			Battledome battledome = Battledome.battledomeChunks.get(coord);

			if (battledome != null) {
				return;
			}

			if (CivSettings.restrictedSpawns.containsKey(event.getEntityType())) {
				event.setCancelled(true);
			}
		}		
	}


	@EventHandler(priority = EventPriority.NORMAL)
	public void OnEntityExplodeEvent(EntityExplodeEvent event) {

		if (event.getEntity() == null) {
			return;
		}
		/* prevent ender dragons from breaking blocks. */
		if (event.getEntityType().equals(EntityType.COMPLEX_PART)) {
			event.setCancelled(true);
		} else if (event.getEntityType().equals(EntityType.ENDER_DRAGON)) {
			event.setCancelled(true);
		}

		for (Block block : event.blockList()) {
			bcoord.setFromLocation(block.getLocation());
			StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
			if (sb != null) {
				event.setCancelled(true);
				return;
			}

			RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
			if (rb != null) {
				event.setCancelled(true);
				return;
			}

			CampBlock cb = CivGlobal.getCampBlock(bcoord);
			if (cb != null) {
				event.setCancelled(true);
				return;
			}

			StructureSign structSign = CivGlobal.getStructureSign(bcoord);
			if (structSign != null) {
				event.setCancelled(true);
				return;
			}

			StructureChest structChest = CivGlobal.getStructureChest(bcoord);
			if (structChest != null) {
				event.setCancelled(true);
				return;
			}

			coord.setFromLocation(block.getLocation());

			HashSet<Wall> walls = CivGlobal.getWallChunk(coord);
			if (walls != null) {
				for (Wall wall : walls) {
					if (wall.isProtectedLocation(block.getLocation())) {
						event.setCancelled(true);
						return;
					}
				}
			}

			TownChunk tc = CivGlobal.getTownChunk(coord);
			if (tc == null) {
				continue;
			}
			event.setCancelled(true);
			return;
		}

	}

     private final BlockFace[] faces = new BlockFace[] {
			        BlockFace.DOWN,
		            BlockFace.NORTH,
		            BlockFace.EAST,
		            BlockFace.SOUTH,
		            BlockFace.WEST,		            
		            BlockFace.SELF,
		            BlockFace.UP
	  };

    public BlockCoord generatesCobble(int id, Block b)
    {
        int mirrorID1 = (id == CivData.WATER_RUNNING || id == CivData.WATER ? CivData.LAVA_RUNNING : CivData.WATER_RUNNING);
        int mirrorID2 = (id == CivData.WATER_RUNNING || id == CivData.WATER ? CivData.LAVA : CivData.WATER);
        for(BlockFace face : faces)
        {
            Block r = b.getRelative(face, 1);
            if(ItemManager.getId(r) == mirrorID1 || ItemManager.getId(r) == mirrorID2)
            {
            	
            	return new BlockCoord(r);
            }
        }
        
        return null;
    }

//    private static void destroyLiquidRecursive(Block source) {
//    	//source.setTypeIdAndData(CivData.AIR, (byte)0, false);
//    	NMSHandler nms = new NMSHandler();
//    	nms.setBlockFast(source.getWorld(), source.getX(), source.getY(), source.getZ(), 0, (byte)0);
//    	
//    	for (BlockFace face : BlockFace.values()) {
//    		Block relative = source.getRelative(face);
//    		if (relative == null) {
//    			continue;
//    		}
//    		
//    		if (!isLiquid(relative.getTypeId())) {
//    			continue;
//    		}
//    		
//    		destroyLiquidRecursive(relative);
//    	}
//    }
    
//    private static boolean isLiquid(int id) {
//    	return (id >= CivData.WATER && id <= CivData.LAVA);
//    }
    
    private static HashSet<BlockCoord> stopCobbleTasks = new HashSet<>();
	@EventHandler(priority = EventPriority.NORMAL)
	public void OnBlockFromToEvent(BlockFromToEvent event) {
		/* Disable cobblestone generators. */
		int id = ItemManager.getId(event.getBlock());
	    if(id >= CivData.WATER && id <= CivData.LAVA)
	    {
	        Block b = event.getToBlock();
	        bcoord.setFromLocation(b.getLocation());

	        int toid = ItemManager.getId(b);
	        if(toid == 0)
	        {
	            BlockCoord other = generatesCobble(id, b);
	        	if(other != null)
	            {
	            	//BlockCoord d = new BlockCoord(event.getToBlock());
//	            	BlockCoord fromCoord = new BlockCoord(event.getBlock());
	            	event.setCancelled(true);

	            	class SyncTask implements Runnable {
	            		BlockCoord block;

	            		public SyncTask(BlockCoord block) {
	            			this.block = block;
	            		}

						@Override
						public void run() {
							ItemManager.setTypeIdAndData(block.getBlock(), CivData.NETHERRACK, (byte)0, true);
							stopCobbleTasks.remove(block);
						}
	            	}

	            	if (!stopCobbleTasks.contains(other)) {
	            		stopCobbleTasks.add(other);
	            		TaskMaster.syncTask(new SyncTask(other), 2);
	            	}

//	            	if (!stopCobbleTasks.contains(fromCoord)) {
//	            		stopCobbleTasks.add(fromCoord);
//	            		TaskMaster.syncTask(new SyncTask(fromCoord));
//	            	}
	            }
	        }
	    }
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void OnBlockFormEvent (BlockFormEvent event) {

		/* Disable cobblestone generators. */
		if (ItemManager.getId(event.getNewState()) == CivData.COBBLESTONE) {
			ItemManager.setTypeId(event.getNewState(), CivData.GRAVEL);
			return;
		}

		if (ItemManager.getId(event.getNewState()) == CivData.OBSIDIAN) {
			ItemManager.setTypeId(event.getNewState(), CivData.NETHER_BRICK);
			return;
		}

		Chunk spreadChunk = event.getNewState().getChunk();
		coord.setX(spreadChunk.getX());
		coord.setZ(spreadChunk.getZ());
		coord.setWorldname(spreadChunk.getWorld().getName());

		TownChunk tc = CivGlobal.getTownChunk(coord);
		if (tc == null) {
			return;
		}

		if (!tc.perms.isFire()) {
			if(event.getNewState().getType() == Material.FIRE) {
				event.setCancelled(true);
			}
		}
	}

	@EventHandler(priority = EventPriority.LOW)
	public void OnBlockPlaceEvent(BlockPlaceEvent event) {
		Resident resident = CivGlobal.getResident(event.getPlayer());

		if (resident == null) {
			event.setCancelled(true);
			return;
		}

		if (resident.isSBPermOverride()) {
			return;
		}

		if ((resident.unit.equals("spy") || resident.timedSpy > 0) && event.getBlock().getLocation().getBlockY() > 100) {
			event.setCancelled(true);
			CivMessage.sendError(resident, CivSettings.localize.localizedString("spy_blockPlace"));
			return;
		}

		bcoord.setFromLocation(event.getBlockAgainst().getLocation());
		StructureSign sign = CivGlobal.getStructureSign(bcoord);
		if (sign != null) {
			event.setCancelled(true);
			return;
		}

		bcoord.setFromLocation(event.getBlock().getLocation());
		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
		if (sb != null) {
			event.setCancelled(true);
			CivMessage.sendError(event.getPlayer(), 
					CivSettings.localize.localizedString("blockBreak_errorStructure")+" "+sb.getOwner().getDisplayName()+" "+CivSettings.localize.localizedString("blockBreak_errorOwnedBy")+" "+sb.getTown().getName());
			return;
		}

		RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
		if (rb != null) {
			if (rb.isAboveRoadBlock()) {
				if (resident.getCiv() != rb.getRoad().getCiv()) {
					event.setCancelled(true);
					CivMessage.sendError(event.getPlayer(), 
							CivSettings.localize.localizedString("blockPlace_errorRoad1")+" "+(Road.HEIGHT-1)+" "+CivSettings.localize.localizedString("blockPlace_errorRoad2"));
				}
			}
			return;
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null && !cb.canBreak(event.getPlayer().getName())) {
			event.setCancelled(true);
			CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorCamp1")+" "+cb.getCamp().getName()+" "+CivSettings.localize.localizedString("blockBreak_errorOwnedBy")+" "+cb.getCamp().getOwner().getName());
			return;
		}  		

		coord.setFromLocation(event.getBlock().getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);
		if (CivSettings.blockPlaceExceptions.get(event.getBlock().getType()) != null) {
			return;
		}

		if (tc != null) {	
			if(!tc.perms.hasPermission(PlotPermissions.Type.BUILD, resident)  && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
				if (War.isWarTime() && resident.hasTown() && 
						resident.getTown().getCiv().getDiplomacyManager().atWarWith(tc.getTown().getCiv())) {
					if (WarRegen.canPlaceThisBlock(event.getBlock())) {
						WarRegen.saveBlock(event.getBlock(), tc.getTown().getName(), true);
						return;
					} else {
						CivMessage.sendErrorNoRepeat(event.getPlayer(), CivSettings.localize.localizedString("blockPlace_errorWar"));
						event.setCancelled(true);
						return;
					}
				} else {
					event.setCancelled(true);
					CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockPlace_errorPermission")+" "+tc.getTown().getName());
				}
			} 
		}

		//Block block = event.getBlockPlaced();

		/* Check if we're going to break too many structure blocks beneath a structure. */
		//LinkedList<StructureBlock> sbList = CivGlobal.getStructureBlocksAt(bcoord.getWorldname(), bcoord.getX(), bcoord.getZ());
		HashSet<Buildable> buildables = CivGlobal.getBuildablesAt(bcoord);
		if (buildables != null) {
			for (Buildable buildable : buildables) {		
				if (!buildable.validated) {
					try {
						buildable.validate(event.getPlayer());
					} catch (CivException e) {
						e.printStackTrace();
					}
					continue;
				}

				/* Building is validated, grab the layer and determine if this would set it over the limit. */
				BuildableLayer layer = buildable.layerValidPercentages.get(bcoord.getY());
				if (layer == null) {
					continue;
				}

				/* Update the layer. */
				layer.current += Buildable.getReinforcementValue(ItemManager.getId(event.getBlockPlaced()));
				if (layer.current < 0) {
					layer.current = 0;
				}
				buildable.layerValidPercentages.put(bcoord.getY(), layer);
				return;
			}
		}

		if (blockForMiner(event.getBlockPlaced().getType())) {
			BlockCoord bcoord = new BlockCoord(event.getBlock());
			if (!CivGlobal.placedBlocks.contains(bcoord)) {
				CivGlobal.placedBlocks.add(bcoord);
			}
			return;
		}

		if (blockForDigger(event.getBlockPlaced().getType())) {
			BlockCoord bcoord = new BlockCoord(event.getBlock());
			if (!CivGlobal.placedBlocks.contains(bcoord)) {
				CivGlobal.placedBlocks.add(bcoord);
			}
			return;
		}

		if (blockForWoodcutter(event.getBlockPlaced().getType())) {
			BlockCoord bcoord = new BlockCoord(event.getBlock());
			if (!CivGlobal.placedBlocks.contains(bcoord)) {
				CivGlobal.placedBlocks.add(bcoord);
			}
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void OnBlockBreakEvent(BlockBreakEvent event) {
		Resident resident = CivGlobal.getResident(event.getPlayer());

		if (resident == null) {
			event.setCancelled(true);
			return;
		}

		if ((resident.unit.equals("spy") || resident.timedSpy > 0) && event.getBlock().getLocation().getBlockY() < 63) {
			event.setCancelled(true);
			CivMessage.sendError(resident, CivSettings.localize.localizedString("spy_blockBreak"));
			return;
		}

		if (resident.isSBPermOverride()) {
			return;
		}

		bcoord.setFromLocation(event.getBlock().getLocation());
		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);

		if (sb != null) {
			event.setCancelled(true);
			TaskMaster.syncTask(new StructureBlockHitEvent(event.getPlayer().getName(), bcoord, sb, event.getBlock().getWorld()), 0);
			return;
		}

		RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
		if (rb != null && !rb.isAboveRoadBlock()) {
			if (War.isWarTime()) {
				/* Allow blocks to be 'destroyed' during war time. */
				WarRegen.destroyThisBlock(event.getBlock(), rb.getTown());
				event.setCancelled(true);
				return;
			} else {
				event.setCancelled(true);
				rb.onHit(event.getPlayer());
				return;
			}
		}

		ProtectedBlock pb = CivGlobal.getProtectedBlock(bcoord);
		if (pb != null) {
			event.setCancelled(true);
			CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorProtected"));
			return;
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null && !cb.canBreak(event.getPlayer().getName())) {
			ControlPoint cBlock = cb.getCamp().controlBlocks.get(bcoord);
			if (cBlock != null) {
				cb.getCamp().onDamage(1, event.getBlock().getWorld(), event.getPlayer(), bcoord, null);
				event.setCancelled(true);
				return;
			} else {	
				event.setCancelled(true);
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorCamp1")+" "+cb.getCamp().getName()+" "+CivSettings.localize.localizedString("blockBreak_errorOwnedBy")+" "+cb.getCamp().getOwner().getName());
				return;
			}
		}

		StructureSign structSign = CivGlobal.getStructureSign(bcoord);
		if (structSign != null && !resident.isSBPermOverride()) {
			event.setCancelled(true);
			CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorStructureSign"));
			return;
		}

		StructureChest structChest = CivGlobal.getStructureChest(bcoord);
		if (structChest != null && !resident.isSBPermOverride()) {
			event.setCancelled(true);
			CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorStructureChests"));
			return;
		}

		coord.setFromLocation(event.getBlock().getLocation());
		HashSet<Wall> walls = CivGlobal.getWallChunk(coord);

		if (walls != null) {
			for (Wall wall : walls) {
				if (wall.isProtectedLocation(event.getBlock().getLocation())) {
					if (!resident.hasTown() || resident.getTown().getCiv() != wall.getTown().getCiv() && !resident.isSBPermOverride()) {
						
						StructureBlock tmpStructureBlock = new StructureBlock(bcoord, wall);
						tmpStructureBlock.setAlwaysDamage(true);
						TaskMaster.syncTask(new StructureBlockHitEvent(event.getPlayer().getName(), bcoord, tmpStructureBlock, event.getBlock().getWorld()), 0);
						event.setCancelled(true);
						return;
					} else {
						CivMessage.send(event.getPlayer(), CivColor.LightGray+CivSettings.localize.localizedString("blockBreak_wallAlert")+" "+
								resident.getTown().getCiv().getName());
						break;
					}
				}
			}
		}

		TownChunk tc = CivGlobal.getTownChunk(coord);
		if (tc != null) {
			if(!tc.perms.hasPermission(PlotPermissions.Type.DESTROY, resident)  && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
				event.setCancelled(true);

				if (War.isWarTime() && resident.hasTown() &&
						(resident.getTown().getCiv().getDiplomacyManager().atWarWith(tc.getTown().getCiv()) || resident.getCiv().getName().equals(tc.getTown().getCiv().getName()))) {
					WarRegen.destroyThisBlock(event.getBlock(), tc.getTown());
				} else {
					CivMessage.sendErrorNoRepeat(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorPermission")+" "+tc.getTown().getName());
				}
			}
		}

		/* Check if we're going to break too many structure blocks beneath a structure. */
		//LinkedList<StructureBlock> sbList = CivGlobal.getStructureBlocksAt(bcoord.getWorldname(), bcoord.getX(), bcoord.getZ());
		HashSet<Buildable> buildables = CivGlobal.getBuildablesAt(bcoord);
		if (buildables != null) {
			for (Buildable buildable : buildables) {
				if (!buildable.validated) {
					try {
						buildable.validate(event.getPlayer());
					} catch (CivException e) {
						e.printStackTrace();
					}
					continue;
				}

				/* Building is validated, grab the layer and determine if this would set it over the limit. */
				BuildableLayer layer = buildable.layerValidPercentages.get(bcoord.getY());
				if (layer == null) {
					continue;
				}

				double current = layer.current - Buildable.getReinforcementValue(ItemManager.getId(event.getBlock()));
				if (current < 0) {
					current = 0;
				}
				Double percentValid = (double)(current) / (double)layer.max;

				if (percentValid < Buildable.validPercentRequirement) {
					CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockBreak_errorSupport")+" "+buildable.getDisplayName());
					event.setCancelled(true);
					return;
				}

				/* Update the layer. */
				layer.current = (int)current;
				buildable.layerValidPercentages.put(bcoord.getY(), layer);
				return;
			}
		}

		bcoord.setFromLocation(event.getBlock().getLocation());
		//Block block = event.getBlock();
		if (blockForWoodcutter(event.getBlock().getType())) {
			if (!CivGlobal.placedBlocks.contains(bcoord) && !event.isCancelled()) {
				resident.jobExpWoodcutter++;

				Random rand = new Random();
				int amount = 0;
				if (resident.jobLevelWoodcutter >= 1) {
					amount = rand.nextInt(resident.getLevelJobWoodcutter()*2)+resident.getLevelJobWoodcutter()*2;
				}
				event.setExpToDrop(amount);

				ConfigJobLevels level = CivSettings.woodcutterLevels.get(resident.jobLevelWoodcutter);

				if (resident.jobLevelWoodcutter != CivSettings.getMaxJobWoodcutterLevel()) {
					if (resident.jobExpWoodcutter >= level.amount) {
						resident.jobLevelWoodcutter++;
						CivMessage.send(resident, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelWoodcutter", resident.jobLevelWoodcutter));
					}
				}
				return;
			}
		}

		if (blockForDigger(event.getBlock().getType())) {
			if (!CivGlobal.placedBlocks.contains(bcoord) && !event.isCancelled()) {
				resident.jobExpDigger++;

				Random rand = new Random();
				int amount = 0;
				if (resident.jobLevelDigger >= 1) {
					amount = rand.nextInt(resident.jobLevelDigger*2)+resident.jobLevelDigger*2;
				}
				event.setExpToDrop(amount);

				ConfigJobLevels level = CivSettings.diggerLevels.get(resident.jobLevelDigger);

				if (resident.jobLevelDigger != CivSettings.getMaxJobDiggerLevel()) {
					if (resident.jobExpDigger >= level.amount) {
						resident.jobLevelDigger++;
						CivMessage.send(resident, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelDigger", resident.jobLevelDigger));
					}
				}
				return;
			}
		}

		if (blockForMiner(event.getBlock().getType())) {
			if (!CivGlobal.placedBlocks.contains(bcoord) && !event.isCancelled()) {
				resident.jobExpMiner++;

				Random rand = new Random();
				int amount = 0;
				if (resident.jobLevelMiner >= 1) {
					amount = rand.nextInt(resident.getLevelJobMiner()*3)+resident.getLevelJobMiner()*2;
				}
				event.setExpToDrop(amount);

				ConfigJobLevels level = CivSettings.minerLevels.get(resident.jobLevelMiner);

				if (resident.jobLevelMiner != CivSettings.getMaxJobMinerLevel()) {
					if (resident.jobExpMiner >= level.amount) {
						resident.jobLevelMiner++;
						CivMessage.send(resident, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelMiner", resident.jobLevelMiner));
					}
				}
				return;
			}
		}

		if (blockIsCrop(event.getBlock().getType())) {
			Crops crop = (Crops) event.getBlock().getState().getData();
			if (crop.getState() == CropState.RIPE && !event.isCancelled()) {
				resident.jobExpFarmer++;

				Random rand = new Random();
				int amount = 0;
				if (resident.jobLevelFarmer >= 1) {
					amount = rand.nextInt(resident.getLevelJobFarmer()*4)+resident.getLevelJobFarmer()*3;
				}
				event.setExpToDrop(amount);
				ConfigJobLevels level = CivSettings.farmerLevels.get(resident.jobLevelFarmer);

				if (resident.jobLevelFarmer != CivSettings.getMaxJobFarmerLevel()) {
					if (resident.jobExpFarmer >= level.amount) {
						resident.jobLevelFarmer++;
						CivMessage.send(resident, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelFarmer", resident.jobLevelFarmer));
					}
				}
			}
		}

	}

	private boolean blockForWoodcutter(Material type) {
		return (type == Material.LOG ||
				type == Material.LOG_2);
	}

	private boolean blockForDigger(Material type) {
		return (type == Material.SAND ||
				type == Material.DIRT ||
				type == Material.GRASS ||
				type == Material.GRAVEL ||
				type == Material.GRASS_PATH);
	}

	private boolean blockIsCrop(Material type) {
		return (type == Material.CROPS ||
				type == Material.POTATO ||
				type == Material.CARROT);
	}

	private boolean blockForMiner(Material type) {
		return (type == Material.IRON_ORE ||
				type == Material.COAL_ORE ||
				type == Material.GOLD_ORE ||
				type == Material.DIAMOND_ORE ||
				type == Material.LAPIS_ORE ||
				type == Material.OBSIDIAN ||
				type == Material.GLOWING_REDSTONE_ORE ||
				type == Material.REDSTONE_ORE ||
				type == Material.EMERALD_ORE);
	}

	private boolean mobForHunter(LivingEntity entity) {
		return (entity.getType() == EntityType.COW ||
				entity.getType() == EntityType.SHEEP ||
				entity.getType() == EntityType.LLAMA ||
				entity.getType() == EntityType.CHICKEN ||
				entity.getType() == EntityType.PIG ||
				entity.getType() == EntityType.MUSHROOM_COW ||
				entity.getType() == EntityType.RABBIT ||
				entity.getType() == EntityType.HORSE);
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void OnEntityInteractEvent(EntityInteractEvent event) {
		if (event.getBlock() != null) {			
			if (CivSettings.switchItems.contains(event.getBlock().getType())) {
				coord.setFromLocation(event.getBlock().getLocation());
				TownChunk tc = CivGlobal.getTownChunk(coord);

				if (tc == null) {
					return;
				}

				/* A non-player entity is trying to trigger something, if interact permission is
				 * off for others then disallow it.
				 */
				if (tc.perms.interact.isPermitOthers()) {
					return;
				}

				if (event.getEntity() instanceof Player) {
					CivMessage.sendErrorNoRepeat((Player)event.getEntity(), CivSettings.localize.localizedString("blockUse_errorPermission"));
				}

				event.setCancelled(true);
			}
		}

	}

	@EventHandler(priority = EventPriority.HIGH)
	public void OnPlayerConsumeEvent(PlayerItemConsumeEvent event) {
		ItemStack stack = event.getItem();

		/* Disable notch apples */
		if (ItemManager.getId(event.getItem()) == ItemManager.getId(Material.GOLDEN_APPLE)) {
			if (event.getItem().getDurability() == (short)0x1) {
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorGoldenApple"));
				event.setCancelled(true);
				return;
			}
		}	

		if (stack.getType().equals(Material.POTION)) {
			int effect = event.getItem().getDurability() & 0x000F;			
			if (effect == 0xE) {
				event.setCancelled(true);
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorInvisPotion"));
			}
		}
	}

	@EventHandler(priority = EventPriority.NORMAL) 
	public void onBlockDispenseEvent(BlockDispenseEvent event) {
		ItemStack stack = event.getItem();
		if (stack != null) {
			if (event.getItem().getType().equals(Material.POTION)) {
				//int effect = event.getItem().getDurability() & 0x000F;
				//if (effect == 0xE) {
					event.setCancelled(true);
					return;
				//}
			}

			if (event.getItem().getType().equals(Material.INK_SACK)) {
				//if (event.getItem().getDurability() == 15) { 
					event.setCancelled(true);
				//}
			}
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void OnPlayerInteractEvent(PlayerInteractEvent event) {
		Resident resident = CivGlobal.getResident(event.getPlayer());

		if (resident == null) {
			event.setCancelled(true);
			return;
		}

		if (event.isCancelled()) {
			// Fix for bucket bug.
			if (event.getAction() == Action.RIGHT_CLICK_AIR) {
				Integer item = ItemManager.getId(event.getPlayer().getInventory().getItemInMainHand());
				// block cheats for placing water/lava/fire/lighter use.
				if (item == 326 || item == 327 || item == 259 || (item >= 8 && item <= 11) || item == 51) { 
					event.setCancelled(true);
				}
			}
			return;
		}

		if (event.getMaterial() == Material.ENDER_PEARL && (event.getAction() == Action.RIGHT_CLICK_AIR ||
				event.getAction() == Action.RIGHT_CLICK_BLOCK ||
				event.getClickedBlock().getType() == Material.AIR)) {
			event.setCancelled(true);
			return;
		}

		if (event.getMaterial() == Material.MONSTER_EGG) {
			ItemMeta meta = event.getItem().getItemMeta();
			SpawnEggMeta eggMeta = (SpawnEggMeta) meta;
			if (eggMeta.getSpawnedType() == EntityType.VILLAGER) {
				event.setCancelled(true);
				return;
			}
		}

		int idw = ItemManager.getId(event.getClickedBlock());

		if ((event.getMaterial() == Material.BOAT ||
				event.getMaterial() == Material.BOAT_ACACIA ||
				event.getMaterial() == Material.BOAT_BIRCH ||
				event.getMaterial() == Material.BOAT_DARK_OAK ||
				event.getMaterial() == Material.BOAT_JUNGLE ||
				event.getMaterial() == Material.BOAT_SPRUCE) && !(idw == CivData.WATER || idw == CivData.WATER_RUNNING || idw == CivData.PACKED_ICE || idw == CivData.ICE)) {
			event.setCancelled(true);
			CivMessage.send(event.getPlayer(), CivColor.Rose+CivSettings.localize.localizedString("player_boat_place_on_ground"));
			return;
		}

		if (event.hasItem()) {
			if (event.getItem().getType() == Material.SPLASH_POTION && (event.getAction() == Action.RIGHT_CLICK_AIR ||
					event.getAction() == Action.RIGHT_CLICK_BLOCK ||
					event.getClickedBlock().getType().equals(Material.AIR))) {
				if (!resident.unit.equals("alchemist")) {
					event.setCancelled(true);
					CivMessage.sendErrorNoRepeat(resident, CivSettings.localize.localizedString("itemUse_errorPotionSplash"));
					return;
				}
			}

			if (event.getItem().getType().equals(Material.POTION)) {
				int effect = event.getItem().getDurability() & 0x000F;			
				if (effect == 0xE) {
					event.setCancelled(true);
					CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorInvisPotion"));
					return;
				}
			}

			if (event.getItem().getType().equals(Material.INK_SACK) && event.getItem().getDurability() == 15) {
				Block clickedBlock = event.getClickedBlock();
				if (ItemManager.getId(clickedBlock) == CivData.WHEAT || 
					ItemManager.getId(clickedBlock) == CivData.CARROTS || 
					ItemManager.getId(clickedBlock) == CivData.POTATOES) {
					event.setCancelled(true);
					CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorBoneMeal"));
					return;
				}
			}
		}

		Block soilBlock = event.getPlayer().getLocation().getBlock().getRelative(BlockFace.DOWN);

		// prevent players trampling crops
		if ((event.getAction() == Action.PHYSICAL)) {
			if ((soilBlock.getType() == Material.SOIL) || (soilBlock.getType() == Material.CROPS)) {
				//CivLog.debug("no crop cancel.");
				event.setCancelled(true);
				return;	
			}
		}
		/* 
		 * Right clicking causes some dupe bugs for some reason with items that have "actions" such as swords.
		 * It also causes block place events on top of signs. So we'll just only allow signs to work with left click.
		 */
		boolean leftClick = event.getAction().equals(Action.LEFT_CLICK_AIR) || event.getAction().equals(Action.LEFT_CLICK_BLOCK);

		if (event.getClickedBlock() != null) {		

			if (MarkerPlacementManager.isPlayerInPlacementMode(event.getPlayer())) {
				Block block;
				if (event.getBlockFace().equals(BlockFace.UP)) {
					block = event.getClickedBlock().getRelative(event.getBlockFace());
				} else {
					block = event.getClickedBlock();
				}

				try {
					MarkerPlacementManager.setMarker(event.getPlayer(), block.getLocation());
					CivMessage.send(event.getPlayer(), CivColor.LightGreen+CivSettings.localize.localizedString("itemUse_marked"));
				} catch (CivException e) {
					CivMessage.send(event.getPlayer(), CivColor.Rose+e.getMessage());
				}

				event.setCancelled(true);
				return;
			}

			// Check for clicked structure signs.
			bcoord.setFromLocation(event.getClickedBlock().getLocation());
			StructureSign sign = CivGlobal.getStructureSign(bcoord);
			if (sign != null) {

				if (leftClick || sign.isAllowRightClick()) {
					if (sign.getOwner() != null && sign.getOwner().isActive()) {
						try {
							sign.getOwner().processSignAction(event.getPlayer(), sign, event);
							event.setCancelled(true);
						} catch (CivException e) {
							CivMessage.send(event.getPlayer(), CivColor.Rose+e.getMessage());
							event.setCancelled(true);
							return;
						}
					}
				}
				return;
			}
			if (CivSettings.switchItems.contains(event.getClickedBlock().getType())) {
				OnPlayerSwitchEvent(event);
				if (event.isCancelled()) {
					return;
				}
			}
		}

		if (event.hasItem()) {

			if (event.getItem() == null) {
			} else {
				if (CivSettings.restrictedItems.containsKey(event.getItem().getType())) {
					OnPlayerUseItem(event);
					if (event.isCancelled()) {
					}
				}
			}
		}

	}
	
	public void OnPlayerBedEnterEvent(PlayerBedEnterEvent event) {
		
		Resident resident = CivGlobal.getResident(event.getPlayer().getName());

		if (resident == null) {
			event.setCancelled(true);
			return;
		}
				
		coord.setFromLocation(event.getPlayer().getLocation());
		Camp camp = CivGlobal.getCampFromChunk(coord);
		if (camp != null) {
			if (!camp.hasMember(event.getPlayer().getName())) {
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("bedUse_errorNotInCamp"));
				event.setCancelled(true);
			}
		}		
	}

	public static void OnPlayerSwitchEvent(PlayerInteractEvent event) {

		if (event.getClickedBlock() == null) {
			return;
		}

		Resident resident = CivGlobal.getResident(event.getPlayer().getName());

		if (resident == null) {
			event.setCancelled(true);
			return;
		}

		bcoord.setFromLocation(event.getClickedBlock().getLocation());
		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null && !resident.isPermOverride()) {
			if (!cb.getCamp().hasMember(resident.getName())) {
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("blockUse_errorNotInCamp"));
				event.setCancelled(true);
				return;
			}
		}

		coord.setFromLocation(event.getClickedBlock().getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);

		if (tc == null) {
			return;
		}

		if (resident.hasTown()) {
			if (War.isWarTime()) {
				if(tc.getTown().getCiv().getDiplomacyManager().atWarWith(resident.getTown().getCiv())) {

					switch (event.getClickedBlock().getType()) {
					case WOODEN_DOOR:
					case IRON_DOOR:
					case SPRUCE_DOOR:
					case BIRCH_DOOR:
					case JUNGLE_DOOR:
					case ACACIA_DOOR:
					case DARK_OAK_DOOR:
                    case ACACIA_FENCE_GATE:
                    case BIRCH_FENCE_GATE:
                    case DARK_OAK_FENCE_GATE: 
                    case FENCE_GATE:
                    case SPRUCE_FENCE_GATE:
                    case JUNGLE_FENCE_GATE: 
						return;
					default:
						break;
					}
				}
			}
		}

		if(!tc.perms.hasPermission(PlotPermissions.Type.INTERACT, resident)  && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
			event.setCancelled(true);

			if (War.isWarTime() && resident.hasTown() && 
					resident.getTown().getCiv().getDiplomacyManager().atWarWith(tc.getTown().getCiv())) {
				WarRegen.destroyThisBlock(event.getClickedBlock(), tc.getTown());
			} else {
				CivMessage.sendErrorNoRepeat(event.getPlayer(), CivSettings.localize.localizedString("blockUse_errorGeneric")+" "+event.getClickedBlock().getType().toString());
			}
		}
	}

	private void OnPlayerUseItem(PlayerInteractEvent event) {
		Location loc = (event.getClickedBlock() == null) ? 
				event.getPlayer().getLocation() : 
				event.getClickedBlock().getLocation();

		ItemStack stack = event.getItem();

		coord.setFromLocation(event.getPlayer().getLocation());
		Camp camp = CivGlobal.getCampFromChunk(coord);
		if (camp != null) {
			if (!camp.hasMember(event.getPlayer().getName())) {
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorCamp")+" "+stack.getType().toString());
				event.setCancelled(true);
				return;
			}
		}

		TownChunk tc = CivGlobal.getTownChunk(loc);
		if (tc == null) {
			return;
		}

		Resident resident = CivGlobal.getResident(event.getPlayer().getName());

		if (resident == null) {
			event.setCancelled(true);
		}

		if(!tc.perms.hasPermission(PlotPermissions.Type.ITEMUSE, resident) && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
			event.setCancelled(true);
			CivMessage.sendErrorNoRepeat(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorGeneric")+" "+stack.getType().toString()+" ");
		}
	}

	/*
	 * Handles rotating of itemframes
	 */
	@EventHandler(priority = EventPriority.HIGHEST)
	public void OnPlayerInteractEntityEvent(PlayerInteractEntityEvent event) {
		if (event.getRightClicked() instanceof Villager) {
			event.setCancelled(true);
			return;
		}

		/*if (event.getRightClicked().getType().equals(EntityType.HORSE)) {
			if (!HorseModifier.isCivCraftHorse((LivingEntity)event.getRightClicked())) {
				CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("horseUse_invalidHorse"));
				event.setCancelled(true);
				event.getRightClicked().remove();
				return;
			}
		}*/

		ItemStack inHand = event.getPlayer().getInventory().getItemInMainHand();
			if (inHand != null) {

				boolean denyBreeding = false;
				switch (event.getRightClicked().getType()) {
				case COW:
				case SHEEP:
				case MUSHROOM_COW:
					if (inHand.getType().equals(Material.WHEAT)) {
						denyBreeding = true;
					}
					break;
				case PIG:
					if (inHand.getType().equals(Material.CARROT_ITEM)) {
						denyBreeding = true;
					}
					break;
				case HORSE:
					if (inHand.getType().equals(Material.GOLDEN_APPLE) ||
							inHand.getType().equals(Material.GOLDEN_CARROT)) {
						CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorNoHorseBreeding"));
						event.setCancelled(true);
						return;
					}
					break;
				case CHICKEN:
					if (inHand.getType().equals(Material.SEEDS) ||
						inHand.getType().equals(Material.MELON_SEEDS) ||
						inHand.getType().equals(Material.PUMPKIN_SEEDS)) {
						denyBreeding = true;
					}
					break;
				case RABBIT:
					if (inHand.getType().equals(Material.CARROT) ||
						inHand.getType().equals(Material.GOLDEN_CARROT) ||
						inHand.getType().equals(Material.YELLOW_FLOWER)) {
						denyBreeding = true;
					}
					break;
				default:
					break;
				}

				if (denyBreeding) {
					ChunkCoord coord = new ChunkCoord(event.getPlayer().getLocation());
					ChunkCoord cc = new ChunkCoord(event.getRightClicked().getLocation());
					Pasture pasture = Pasture.pastureChunks.get(coord);
					Pasture past = Pasture.pastureChunks.get(cc);

					if (pasture == null || past == null) {
						CivMessage.sendError(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorNoWildBreeding"));
						event.setCancelled(true);
					} else {
						Resident resident = CivGlobal.getResident(event.getPlayer());
						resident.jobExpFarmer += 10;
						ConfigJobLevels level = CivSettings.farmerLevels.get(resident.jobLevelFarmer);
						if (resident.jobLevelFarmer != CivSettings.getMaxJobFarmerLevel()) {
							if (resident.jobExpFarmer >= level.amount) {
								resident.jobLevelFarmer++;
								CivMessage.send(resident, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelFarmer", resident.jobLevelFarmer));
							}
						}
						int loveTicks;
						NBTTagCompound tag = new NBTTagCompound();
						((CraftEntity)event.getRightClicked()).getHandle().c(tag);
						loveTicks = tag.getInt("InLove");

						if (loveTicks == 0) {
							if(!pasture.processMobBreed(event.getPlayer())) {
								event.setCancelled(true);
							}
						} else {
							event.setCancelled(true);
						}
					}

					return;			
				}
			}
		if (!(event.getRightClicked() instanceof ItemFrame) && !(event.getRightClicked() instanceof Painting)) {
			return;
		}

		coord.setFromLocation(event.getPlayer().getLocation());
		TownChunk tc = CivGlobal.getTownChunk(coord);
		if (tc == null) {
			return;
		}

		Resident resident = CivGlobal.getResident(event.getPlayer().getName());
		if (resident == null) {
			return;
		}

		if(!tc.perms.hasPermission(PlotPermissions.Type.INTERACT, resident)  && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
			event.setCancelled(true);
			CivMessage.sendErrorNoRepeat(event.getPlayer(), CivSettings.localize.localizedString("itemUse_errorPaintingOrFrame"));
		}

	}


	/*
	 * Handles breaking of paintings and itemframes.
	 */
	@EventHandler(priority = EventPriority.NORMAL)
	public void OnHangingBreakByEntityEvent(HangingBreakByEntityEvent event) {	
	//	CivLog.debug("hanging painting break event");

		ItemFrameStorage frameStore = CivGlobal.getProtectedItemFrame(event.getEntity().getUniqueId());
		if (frameStore != null) {		
//			if (!(event.getRemover() instanceof Player)) {
//				event.setCancelled(true);
//				return;
//			}
//			
//			if (frameStore.getTown() != null) {
//				Resident resident = CivGlobal.getResident((Player)event.getRemover());
//				if (resident == null) {
//					event.setCancelled(true);
//					return;
//				}
//				
//				if (resident.hasTown() == false || resident.getTown() != frameStore.getTown()) {
//					event.setCancelled(true);
//					CivMessage.sendError((Player)event.getRemover(), "Cannot remove item from protected item frame. Belongs to another town.");
//					return;
//				}
//			}
//			
//			CivGlobal.checkForEmptyDuplicateFrames(frameStore);
//			
//			ItemStack stack = ((ItemFrame)event.getEntity()).getItem();
//			if (stack != null && !stack.getType().equals(Material.AIR)) {
//				BonusGoodie goodie = CivGlobal.getBonusGoodie(stack);
//				if (goodie != null) {
//					frameStore.getTown().onGoodieRemoveFromFrame(frameStore, goodie);
//				}
//				frameStore.clearItem();
//				TaskMaster.syncTask(new DelayItemDrop(stack, event.getEntity().getLocation()));
//			}
			if (event.getRemover() instanceof Player) {
				CivMessage.sendError(event.getRemover(), CivSettings.localize.localizedString("blockBreak_errorItemFrame"));
			}
			event.setCancelled(true);	
			return;
		}

		if (event.getRemover() instanceof Player) {
			Player player = (Player)event.getRemover();

			coord.setFromLocation(player.getLocation());
			TownChunk tc = CivGlobal.getTownChunk(coord);

			if (tc == null) {
				return;
			}

			Resident resident = CivGlobal.getResident(player.getName());
			if (resident == null) {
				event.setCancelled(true);
			}

			if (!tc.perms.hasPermission(PlotPermissions.Type.DESTROY, resident)  && !tc.getTown().getCiv().getLeaderGroup().hasMember(resident)) {
				event.setCancelled(true);
				CivMessage.sendErrorNoRepeat(player, CivSettings.localize.localizedString("blockBreak_errorFramePermission"));
			}
		}


	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onChunkUnloadEvent(ChunkUnloadEvent event) {
		Boolean persist = CivGlobal.isPersistChunk(event.getChunk());		
		if (persist != null && persist == true) {
			event.setCancelled(true);
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void onChunkLoadEvent(ChunkLoadEvent event) {
		ChunkCoord coord = new ChunkCoord(event.getChunk());
		FarmChunk fc = CivGlobal.getFarmChunk(coord);
		if (fc == null) {
			return;
		}

		for (org.bukkit.entity.Entity ent : event.getChunk().getEntities()) {
			if (ent.getType().equals(EntityType.ZOMBIE)) {
				ent.remove();
			}
		}

		class AsyncTask extends CivAsyncTask {

			FarmChunk fc;
			public AsyncTask(FarmChunk fc) {
				this.fc = fc;
			}

			@Override
			public void run() {
				if (fc.getMissedGrowthTicks() > 0) {
					fc.processMissedGrowths(false, this);
					fc.getFarm().saveMissedGrowths();
				}
			}

		}

		TaskMaster.syncTask(new AsyncTask(fc), 500);
	}

	@EventHandler(priority = EventPriority.MONITOR)
	public void onEntityDeath(EntityDeathEvent event) {
		if (mobForHunter(event.getEntity()) && event.getEntity().getKiller() != null) {
			Resident res = CivGlobal.getResident(event.getEntity().getKiller());
			res.jobExpHunter++;

			Random rand = new Random();
			int amount = rand.nextInt(5);
			if (res.jobLevelHunter >= 1) {
				amount = rand.nextInt(res.getLevelJobHunter()*3)+res.getLevelJobHunter()*3;
			}
			event.setDroppedExp(amount);

			ConfigJobLevels level = CivSettings.hunterLevels.get(res.jobLevelHunter);

			if (res.jobLevelHunter != CivSettings.getMaxJobMinerLevel()) {
				if (res.jobExpHunter >= level.amount) {
					res.jobLevelHunter++;
					CivMessage.send(res, CivColor.LightGreen+CivSettings.localize.localizedString("var_res_uplevelHunter", res.jobLevelHunter));
				}
			}
		}

		if (event.getEntityType() == EntityType.ENDER_DRAGON) {
			Location loc = CivGlobal.locBossDragon;
			class SyncTask implements Runnable {
				@Override
				public void run() {
					for(int x = -3; x < 4; x++) {
						for (int y = -3; y < 4; y++) {
							for (int z = -3; z < 4; z++) {
								Block block = loc.getWorld().getBlockAt(loc.getBlockX()+x, loc.getBlockY()+y, loc.getBlockZ()+z);
								if (block.getType() == Material.ENDER_PORTAL)
									block.setType(Material.BEDROCK);
							}
						}
					}
				}
			}
			TaskMaster.syncTask(new SyncTask(), TimeTools.toTicks(15));
		}

		Pasture pasture = Pasture.pastureEntities.get(event.getEntity().getUniqueId());
		if (pasture != null) {
			pasture.onEntityDeath(event.getEntity());
		}
		
		Battledome battledome = Battledome.battledomeEntities.get(event.getEntity().getUniqueId());
		if (battledome != null) {
			battledome.onEntityDeath(event.getEntity());
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void onBlockGrowEvent(BlockGrowEvent event) {
		bcoord.setFromLocation(event.getBlock().getLocation().add(0, -1, 0));
		if (CivGlobal.vanillaGrowthLocations.contains(bcoord)) {
			/* Allow vanilla growth on these plots. */
			return;
		}

		Block b = event.getBlock();

		if (Farm.isBlockControlled(b)) {
			event.setCancelled(true);
		}
	}

	@EventHandler(priority = EventPriority.HIGH)
	public void onEntityBreakDoor(EntityBreakDoorEvent event) {
		bcoord.setFromLocation(event.getBlock().getLocation());
		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
		if (sb != null) {
			event.setCancelled(true);
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null) {
			event.setCancelled(true);
		}
	}

	@EventHandler(priority = EventPriority.NORMAL)
	public void onCreatureSpawnEvent(CreatureSpawnEvent event) {
		if (War.isWarTime() && !event.getEntity().getType().equals(EntityType.HORSE)) {
			if (!event.getSpawnReason().equals(SpawnReason.BREEDING)){
				event.setCancelled(true);
				return;
			}
		}
		
		if (event.getEntity().getType().equals(EntityType.CHICKEN)) {
			if (event.getSpawnReason().equals(SpawnReason.EGG)) {
				event.setCancelled(true);
				return;
			}
			NBTTagCompound compound = new NBTTagCompound();
			if (compound.getBoolean("IsChickenJockey")) {
				event.setCancelled(true);
				return;			
			}
		}

		if (event.getEntity().getType().equals(EntityType.IRON_GOLEM) &&
			event.getSpawnReason().equals(SpawnReason.BUILD_IRONGOLEM)) {
				event.setCancelled(true);
				return;
		}

//		if (event.getEntity().getType().equals(EntityType.ZOMBIE) ||
//			event.getEntity().getType().equals(EntityType.SKELETON) ||
//			event.getEntity().getType().equals(EntityType.BAT) ||
//			event.getEntity().getType().equals(EntityType.CAVE_SPIDER) ||
//			event.getEntity().getType().equals(EntityType.SPIDER) ||
//			event.getEntity().getType().equals(EntityType.CREEPER) ||
//			event.getEntity().getType().equals(EntityType.WOLF) ||
//			event.getEntity().getType().equals(EntityType.SILVERFISH) ||
//			event.getEntity().getType().equals(EntityType.OCELOT) ||
//			event.getEntity().getType().equals(EntityType.WITCH) ||
//			event.getEntity().getType().equals(EntityType.ENDERMAN)) {
//
//			event.setCancelled(true);
//			return;
//		}

		if (event.getSpawnReason().equals(SpawnReason.SPAWNER)) {
			event.setCancelled(true);
		}
	}

	@EventHandler(priority = EventPriority.MONITOR)
	public void onBlockEvent(EntityCreatePortalEvent event) {
		if (event.getPortalType() == PortalType.ENDER) {
			event.setCancelled(true);
		}
	}

	public boolean allowPistonAction(Location loc) {
		bcoord.setFromLocation(loc);
		StructureBlock sb = CivGlobal.getStructureBlock(bcoord);
		if (sb != null) {
			return false;
		}

		RoadBlock rb = CivGlobal.getRoadBlock(bcoord);
		if (rb != null) {
			return false;
		}

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null) {
			return false;
		}

		/* 
		 * If we're next to an attached protected item frame. Disallow 
		 * we cannot break protected item frames.
		 * 
		 * Only need to check blocks directly next to us.
		 */
		BlockCoord bcoord2 = new BlockCoord(bcoord);
		bcoord2.setX(bcoord.getX() - 1);
		if (ItemFrameStorage.attachedBlockMap.containsKey(bcoord2)) {
			return false;
		}

		bcoord2.setX(bcoord.getX() + 1);
		if (ItemFrameStorage.attachedBlockMap.containsKey(bcoord2)) {
			return false;
		}

		bcoord2.setZ(bcoord.getZ() - 1);
		if (ItemFrameStorage.attachedBlockMap.containsKey(bcoord2)) {
			return false;
		}

		bcoord2.setZ(bcoord.getZ() + 1);
		if (ItemFrameStorage.attachedBlockMap.containsKey(bcoord2)) {
			return false;
		}

		coord.setFromLocation(loc);
		HashSet<Wall> walls = CivGlobal.getWallChunk(coord);

		if (walls != null) {
			for (Wall wall : walls) {
				if (wall.isProtectedLocation(loc)) {
					return false;
				}
			}
		}		

		return true;
	}

	@EventHandler(priority = EventPriority.HIGHEST) 
	public void onBlockPistonExtendEvent(BlockPistonExtendEvent event) {

		/* UGH. If we extend into 'air' it doesnt count them as blocks...
		 * we need to check air to prevent breaking of item frames...
		 */
		final int PISTON_EXTEND_LENGTH = 13;
		Block currentBlock = event.getBlock().getRelative(event.getDirection());
		for (int i = 0; i < PISTON_EXTEND_LENGTH; i++) {
			if(ItemManager.getId(currentBlock) == CivData.AIR) {
				if (!allowPistonAction(currentBlock.getLocation())) {
					event.setCancelled(true);
					return;
				}
			}

			currentBlock = currentBlock.getRelative(event.getDirection());
		}
		
		if (War.isWarTime()) {
			event.setCancelled(true);
			return;
		}

//		if (event.getBlocks().size() == 0) {
//			Block extendInto = event.getBlock().getRelative(event.getDirection());
//			if (!allowPistonAction(extendInto.getLocation())) {
//				event.setCancelled(true);
//				return;
//			}
//		}
		coord.setFromLocation(event.getBlock().getLocation());
		FarmChunk fc = CivGlobal.getFarmChunk(coord);
		if (fc == null) {
			event.setCancelled(true);
			
		}
		
		for (Block block : event.getBlocks()) {
			if (!allowPistonAction(block.getLocation())) {
				event.setCancelled(true);
				break;

			}
		}

	}

	@EventHandler(priority = EventPriority.HIGHEST) 
	public void onBlockPistonRetractEvent(BlockPistonRetractEvent event) {
		for (Block block: event.getBlocks())
		{
			if (!allowPistonAction(block.getLocation())) {
				event.setCancelled(true);
				return;
			}
		}
	}

	@EventHandler(priority = EventPriority.HIGHEST) 
	public void onProjectileLaunchEvent(ProjectileLaunchEvent event) {
		if (!(event.getEntity() instanceof ThrownPotion)) {
			return;
		}
		ThrownPotion potion = (ThrownPotion) event.getEntity();
		if (!(potion.getShooter() instanceof Player)) {
			//Get Ruffian type here and change damage type based on the potion thrown
			//Also change effect based on ruffian type
			String entityName = null;
			LivingEntity shooter = (LivingEntity) potion.getShooter();
			Witch witch = (Witch) shooter;
			
			if (!(witch.getTarget() instanceof Player)) {
				return;
			}
			if (potion.getShooter() instanceof LivingEntity) {
				entityName = shooter.getCustomName();
			}
			if (entityName != null && entityName.endsWith(" Ruffian")) {
				EntityInsentient nmsEntity = (EntityInsentient) ((CraftLivingEntity) shooter).getHandle();
		    	AttributeInstance attribute = nmsEntity.getAttributeInstance(GenericAttributes.ATTACK_DAMAGE);
		    	Double damage = attribute.getValue();
				
				class RuffianProjectile {
					Location loc;
					Location target;
					org.bukkit.entity.Entity attacker;
					int speed = 1;
					double damage;
					int splash = 6;
					
					public RuffianProjectile(Location loc, Location target, org.bukkit.entity.Entity attacker, double damage) {
						this.loc = loc;
						this.target = target;
						this.attacker = attacker;
						this.damage = damage;
					}

					public Vector getVectorBetween(Location to, Location from) {
						Vector dir = new Vector();
						
						dir.setX(to.getX() - from.getX());
						dir.setY(to.getY() - from.getY());
						dir.setZ(to.getZ() - from.getZ());
					
						return dir;
					}
					
					public boolean advance() {
						Vector dir = getVectorBetween(target, loc).normalize();
						double distance = loc.distanceSquared(target);		
						dir.multiply(speed);
						
						loc.add(dir);
						loc.getWorld().createExplosion(loc, 0.0f, false);
						distance = loc.distanceSquared(target);
						
						if (distance < speed*1.5) {
							loc.setX(target.getX());
							loc.setY(target.getY());
							loc.setZ(target.getZ());
							this.onHit();
							return true;
						}
						
						return false;
					}
					
					public void onHit() {				
						int spread = 3;
						int[][] offset = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
						for (int i = 0; i < 4; i++) {
							int x = offset[i][0]*spread;
							int y = 0;
							int z = offset[i][1]*spread;
							
							Location location = new Location(loc.getWorld(), loc.getX(),loc.getY(), loc.getZ());
							location = location.add(x, y, z);
							
							launchExplodeFirework(location);
							//loc.getWorld().createExplosion(location, 1.0f, true);
							//setFireAt(location, spread);
						}
						
						launchExplodeFirework(loc);
						//loc.getWorld().createExplosion(loc, 1.0f, true);
						damagePlayers(loc, splash);
						//setFireAt(loc, spread);		
					}
					
					@SuppressWarnings("deprecation")
					private void damagePlayers(Location loc, int radius) {
						double x = loc.getX()+0.5;
						double y = loc.getY()+0.5;
						double z = loc.getZ()+0.5;
						double r = (double)radius;
						
						CraftWorld craftWorld = (CraftWorld)attacker.getWorld();
						
						AxisAlignedBB bb = AxisAlignedBB(x-r, y-r, z-r, x+r, y+r, z+r);
						
						List<Entity> entities = craftWorld.getHandle().getEntities(((CraftEntity)attacker).getHandle(), bb);
						
						for (Entity e : entities) {
							if (e instanceof EntityPlayer) {
								EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(attacker, ((EntityPlayer)e).getBukkitEntity(), DamageCause.ENTITY_ATTACK, damage);
								Bukkit.getServer().getPluginManager().callEvent(event);
								e.damageEntity(DamageSource.GENERIC, (float) event.getDamage());
							}
						}
						
					}
					
					
//					private void setFireAt(Location loc, int radius) {
//						//Set the entire area on fire.
//						for (int x = -radius; x < radius; x++) {
//							for (int y = -3; y < 3; y++) {
//								for (int z = -radius; z < radius; z++) {
//									Block block = loc.getWorld().getBlockAt(loc.getBlockX()+x, loc.getBlockY()+y, loc.getBlockZ()+z);
//									if (ItemManager.getId(block) == CivData.AIR) {
//										ItemManager.setTypeId(block, CivData.FIRE);
//										ItemManager.setData(block, 0, true);
//									}
//								}
//							}
//						}
//					}

					private AxisAlignedBB AxisAlignedBB(double d, double e,
							double f, double g, double h, double i) {
						 return new AxisAlignedBB(d, e, f, g, h, i);
//						return null;
					}

					private void launchExplodeFirework(Location loc) {
						FireworkEffect fe = FireworkEffect.builder().withColor(Color.ORANGE).withColor(Color.YELLOW).with(Type.BURST).withTrail().build();
						TaskMaster.syncTask(new FireWorkTask(fe, loc.getWorld(), loc, 1), 0);
					}
				}
				
				
				class SyncFollow implements Runnable {
					public RuffianProjectile proj;
					
					@Override
					public void run() {
						
						if (proj.advance()) {
							proj = null;
							return;
						}
						TaskMaster.syncTask(this, 1);
					}
				}
				
				SyncFollow follow = new SyncFollow();
				RuffianProjectile proj = new RuffianProjectile(shooter.getLocation(), 
						witch.getTarget().getLocation(), (org.bukkit.entity.Entity) potion.getShooter(), damage);
				follow.proj = proj;
				TaskMaster.syncTask(follow);
				

				event.setCancelled(true);
			}
		} 
	}
	

	@EventHandler(priority = EventPriority.HIGHEST) 
	public void onPotionSplashEvent(PotionSplashEvent event) {
		ThrownPotion potion = event.getPotion();
		if (!(potion.getShooter() instanceof Player)) {
			return;
		}

		if (event.getHitEntity() instanceof NPC) {
			return;
		}

		Player attacker = (Player)potion.getShooter();

		for (PotionEffect effect : potion.getEffects()) {
			if (effect.getType().equals(PotionEffectType.INVISIBILITY)) {
				event.setCancelled(true);
				return;
			}
		}

		boolean protect = false;
		for (PotionEffect effect : potion.getEffects()) {
			if (effect.getType().equals(PotionEffectType.BLINDNESS) ||
				effect.getType().equals(PotionEffectType.CONFUSION) ||
				effect.getType().equals(PotionEffectType.HARM) ||
				effect.getType().equals(PotionEffectType.POISON) ||
				effect.getType().equals(PotionEffectType.SLOW) ||
				effect.getType().equals(PotionEffectType.SLOW_DIGGING) ||
				effect.getType().equals(PotionEffectType.WEAKNESS) ||
				effect.getType().equals(PotionEffectType.WITHER)) {

				protect = true;
				break;
			}
		}

		if (!protect) {
			return;
		}

		for (LivingEntity entity : event.getAffectedEntities()) {
			if (entity instanceof Player) {
				Player defender = (Player)entity;
				coord.setFromLocation(entity.getLocation());
				TownChunk tc = CivGlobal.getTownChunk(coord);
				if (tc == null) {
					continue;
				}

				switch(playersCanPVPHere(attacker, defender, tc)) {
				case ALLOWED:
					continue;
				case NOT_AT_WAR:
					CivMessage.send(attacker, CivColor.Rose+CivSettings.localize.localizedString("var_itemUse_potionError1",defender.getName()));
					event.setCancelled(true);
					return;
				case NEUTRAL_IN_WARZONE:
					CivMessage.send(attacker, CivColor.Rose+CivSettings.localize.localizedString("var_itemUse_potionError2",defender.getName()));
					event.setCancelled(true);
					return;
				case NON_PVP_ZONE:
					CivMessage.send(attacker, CivColor.Rose+CivSettings.localize.localizedString("var_itemUse_potionError3",defender.getName()));
					event.setCancelled(true);
					return;
				}
			}
		}
	}

	@EventHandler(priority = EventPriority.NORMAL) 
	public void onBlockRedstoneEvent(BlockRedstoneEvent event) {
		
		bcoord.setFromLocation(event.getBlock().getLocation());

		CampBlock cb = CivGlobal.getCampBlock(bcoord);
		if (cb != null) {
			if (ItemManager.getId(event.getBlock()) == CivData.WOOD_DOOR ||
					ItemManager.getId(event.getBlock()) == CivData.IRON_DOOR||
					ItemManager.getId(event.getBlock()) == CivData.SPRUCE_DOOR||
					ItemManager.getId(event.getBlock()) == CivData.BIRCH_DOOR||
					ItemManager.getId(event.getBlock()) == CivData.JUNGLE_DOOR||
					ItemManager.getId(event.getBlock()) == CivData.ACACIA_DOOR||
					ItemManager.getId(event.getBlock()) == CivData.DARK_OAK_DOOR) {
				event.setNewCurrent(0);
				return;
			}
		}
		
		if (War.isWarTime()) {
			event.setNewCurrent(0);
			return;
		}

	}

	private enum PVPDenyReason {
		ALLOWED,
		NON_PVP_ZONE,
		NOT_AT_WAR,
		NEUTRAL_IN_WARZONE
	}

	public PVPDenyReason playersCanPVPHere(Player attacker, Player defender, TownChunk tc) {
		Resident defenderResident = CivGlobal.getResident(defender);
		Resident attackerResident = CivGlobal.getResident(attacker);
		PVPDenyReason reason = PVPDenyReason.NON_PVP_ZONE;

		if (tc != null && tc.getTown().getCiv().isAdminCiv()) {
			return reason;
		}

		/* Outlaws can only pvp each other if they are declared at this location. */
		if (CivGlobal.isOutlawHere(defenderResident, tc) || 
			CivGlobal.isOutlawHere(attackerResident, tc)) {
			return PVPDenyReason.ALLOWED;
		}

		/* 
		 * If it is WarTime and the town we're in is at war, allow neutral players to be 
		 * targeted by anybody.
		 */
		if (War.isWarTime()) {
			if (tc.getTown().getCiv().getDiplomacyManager().isAtWar()) {
				/* 
				 * The defender is neutral if he is not in a town/civ, or not in his own civ AND not 'at war'
				 * with the attacker.
				 */
				if (!defenderResident.hasTown() || (!defenderResident.getTown().getCiv().getDiplomacyManager().atWarWith(tc.getTown().getCiv()) && 
						defenderResident.getTown().getCiv() != tc.getTown().getCiv())) {
					/* Allow neutral players to be hurt, but not hurt them back. */
					return PVPDenyReason.ALLOWED;
				} else if (!attackerResident.hasTown() || (!attackerResident.getTown().getCiv().getDiplomacyManager().atWarWith(tc.getTown().getCiv()) &&
						attackerResident.getTown().getCiv() != tc.getTown().getCiv())) {
					reason = PVPDenyReason.NEUTRAL_IN_WARZONE;
				}
			}
		}

		boolean defenderAtWarWithAttacker = false;
		if (defenderResident != null && defenderResident.hasTown()) {
			defenderAtWarWithAttacker = defenderResident.getTown().getCiv().getDiplomacyManager().atWarWith(attacker);
			/* 
			 * If defenders are at war with attackers allow PVP. Location doesnt matter. Allies should be able to help
			 * defend each other regardless of where they are currently located.
			 */
			if (defenderAtWarWithAttacker) {
				//if (defenderResident.getTown().getCiv() == tc.getTown().getCiv() ||
				//	attackerResident.getTown().getCiv() == tc.getTown().getCiv()) {
					return PVPDenyReason.ALLOWED;
				//}
			} else if (reason.equals(PVPDenyReason.NON_PVP_ZONE)) {
				reason = PVPDenyReason.NOT_AT_WAR;
			}
		}

		return reason;
	}

	@EventHandler(priority = EventPriority.LOW)
	public void onEntityPortalCreate(EntityCreatePortalEvent event) {
		event.setCancelled(true);
	}

}
