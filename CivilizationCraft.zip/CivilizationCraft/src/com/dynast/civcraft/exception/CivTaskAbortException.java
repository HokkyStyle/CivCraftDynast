package com.dynast.civcraft.exception;

public class CivTaskAbortException extends Exception {
	private static final long serialVersionUID = 1124555676255765506L;

	public CivTaskAbortException(String message) {
		super(message);
	}

}
