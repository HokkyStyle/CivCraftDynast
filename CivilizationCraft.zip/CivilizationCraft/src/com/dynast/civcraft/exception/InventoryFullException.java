
package com.dynast.civcraft.exception;

public class InventoryFullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7319210530660943548L;

}
