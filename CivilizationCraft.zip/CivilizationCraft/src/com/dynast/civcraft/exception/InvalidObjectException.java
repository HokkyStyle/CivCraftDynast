
package com.dynast.civcraft.exception;

public class InvalidObjectException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1259447410311608050L;

	public InvalidObjectException(String message) {
		super(message);
	}
	
}
