
package com.dynast.civcraft.exception;

public class AlreadyRegisteredException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5711150822233792374L;
	
	public AlreadyRegisteredException(String message) {
		super(message);
	}

}
