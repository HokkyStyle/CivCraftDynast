
package com.dynast.civcraft.exception;

public class InvalidBlockLocation extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -945041178494359650L;

}
