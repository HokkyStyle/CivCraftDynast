
package com.dynast.civcraft.exception;

public class CivException extends Exception {

	private static final long serialVersionUID = 2752707013644337603L;

	public CivException(String message) {
		super(message);
	}
}
