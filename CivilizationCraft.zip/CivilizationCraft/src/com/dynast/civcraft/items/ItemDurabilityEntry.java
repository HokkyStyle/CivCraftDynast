
package com.dynast.civcraft.items;

import org.bukkit.inventory.ItemStack;

public class ItemDurabilityEntry {
	public ItemStack stack;
	public short oldValue;
}
