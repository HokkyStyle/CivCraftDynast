package com.dynast.civcraft.items.units;

public class Wizard {
}
