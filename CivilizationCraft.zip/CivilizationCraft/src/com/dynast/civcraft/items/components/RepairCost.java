package com.dynast.civcraft.items.components;

import gpl.AttributeUtil;

public class RepairCost extends ItemComponent {

	@Override
	public void onPrepareCreate(AttributeUtil attrUtil) {
	}

}
