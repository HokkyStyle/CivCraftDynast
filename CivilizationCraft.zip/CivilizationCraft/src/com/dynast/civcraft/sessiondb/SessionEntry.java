
package com.dynast.civcraft.sessiondb;

public class SessionEntry {
	public int request_id;
	public String key;
	public String value;
	public int civ_id;
	public int town_id;
	public int struct_id;
	public long time;
}
