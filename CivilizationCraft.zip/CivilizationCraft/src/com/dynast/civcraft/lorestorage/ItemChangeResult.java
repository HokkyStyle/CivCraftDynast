package com.dynast.civcraft.lorestorage;

import org.bukkit.inventory.ItemStack;

public class ItemChangeResult {
	public ItemChangeResult() {
	}
	
	public ItemStack stack;
	public boolean destroyItem;
}
